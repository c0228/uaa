<div id="resumeProject1">
 <h4 class="resume-project-title">2. ROGER'S IVR SOLUTION</h4>
 <div class="resume-project-title">CCBU DEMO PORTAL <span class="badge bg-warning black pull-right">PROJECT</span></div>
</div>