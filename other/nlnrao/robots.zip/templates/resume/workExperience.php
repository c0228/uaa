<div class="resume-header-main"><b>My Work Experience</b><hr class="green-border-3"/></div>

<div class="mtop15p mbot15p">
 <ul>
  <li class="mtop15p">Worked as <span class="grey-2"><b>Software Engineer</b></span> in <span class="grey-2"><b>Synergy Netsoft Limited</b></span> from June 2012 
  to March 2018.</li>
  <li class="mtop15p">Worked as <span class="grey-2"><b>Software Engineer</b></span> (Contract Role) in <span class="grey-2"><b>United Health Group</b></span> 
  (Under payroll of <span class="grey-2"><b>Technosoft Company</b></span>) from March 2018 to June 2018</li>
  <li class="mtop15p">Worked as <span class="grey-2"><b>Senior Associate Projects (Technical Lead)</b></span> in 
  <span class="grey-2"><b>Cognizant Technology Solutions (CTS)</b></span> from November 2018 toJune 2021</li>
  <li class="mtop15p">Worked as <span class="grey-2"><b>Technical Lead</b></span> in <span class="grey-2"><b>Quadratics Software Systems</b></span> 
  from June 2021 to April 2022</li>
  <li class="mtop15p">Working as <span class="grey-2"><b>Technical Lead</b></span> in <span class="grey-2"><b>Tescra Software Systems</b></span> 
  from May 2022 to till Now</li>
 </ul>
</div>
