<div class="resume-header-main"><b>My Professional Experience</b><hr/></div>
<div class="resume-header-sub1 pt-1 pb-1 px-2 mb-3"><b>SYNERGY NETSOFT PVT. LTD <span class="pull-right">( X years Y months)</span></b></div>
<div class="white pb-3"><b>PROJECT #1: CISCO CCBU DEMO PORTAL</b></div>
<div class="card resume-card mb-3">
	<div class="card-body resume-cardBody">
	  <div class="row">
		<div class="col-sm-6">
			<div><span class="grey-3"><b>My Job Title :</b></span> Software Engineer</div>
		</div>
		<div class="col-sm-6">
			<div><span class="grey-3"><b>Team Size :</b></span> 8 Employees</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-sm-12">
			<div class="pt-3"><span class="grey-3"><b>My Work Duration :</b></span> JULY 2012 - DEC 2014 <span class="badge bg-secondary">2 Year and 6 months</span></div>
		</div>
	  </div>
	  <div class="pt-3">
		<span class="grey-3"><b>About Project :</b></span> Python
	  </div>
	  <div class="pt-3">
		<span class="grey-3"><b>My Roles and Responsibilities :</b></span> Python
	  </div>
	  <div class="pt-3">
		<span class="badge bg-warning black">HTML</span> <span class="badge bg-warning black">CSS</span> <span class="badge bg-warning black">Javascript</span>
	  </div>
	  <div align="right">
		
	  </div>
	</div>
</div>