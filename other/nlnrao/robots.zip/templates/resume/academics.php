<div class="resume-header-main"><b>My Academic Details</b><hr class="green-border-3"/></div>

<div class="card resume-card mb-3">
	<div class="card-body resume-cardBody">
		Completed <span class="grey-2"><b>B.Tech in Electrical and Electronics Engineering</b></span> from RVR Engineering and Technologies 
		(Affiliated by JNTU, Hyderabad) with 73.81% (DISTINCTION) from the year 2008 - 2012</li>
	</div>
</div>