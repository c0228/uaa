<nav class="navbar" style="background-color:#7f1231;box-shadow:1px 1px 1px 1px #ddd;border-radius:0px;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="border:2px solid #fff;">
        <i class="fa fa-bars" style="color:#fff;"></i>
      </button>
      <a class="navbar-brand" href="#" style="color:#fff;">
	 <span style="font-size:18px;font-weight:bold;">
	 <span>nellutlalnrao.com</span>
	 </span>
	</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="#"  class="active">Home</a></li>
        <li><a href="#">Page 1</a></li>
        <li><a href="#">Page 2</a></li>
        <li><a href="#">Page 3</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>


<style>
.navbar-nav li a, .navbar-nav li a:link, .navbar-nav li a:visited  {  background-color:#7f1231;color:#fff !important; }
.navbar-nav li a.active { color:#fff !important;border-bottom:2px solid #fff; }
.navbar-nav li a:hover { background-color:#7f1231;color:#ccc; }
</style>