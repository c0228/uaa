<div class="list-group">
<div class="list-group-item mtop35p bg-lgt-red" style="line-height:26px;">
<div class="f18" style="color:brown;"><b>Prerequisites</b></div>
<ul>
 <li>Java 17 Programming language</li>
 <li>Spring Boot Framework</li>
 <li>Designing Microservices</li>
 <li>Understanding Distributed Systems Architecture</li>
</ul>
</div><!--/.list-group-item -->
</div><!--/.list-group -->

<div class="f18" style="color:brown;"><b>Related Articles</b></div>