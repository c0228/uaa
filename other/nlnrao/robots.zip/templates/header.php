<nav class="navbar navbar-expand-sm" style="background-color:#7f1231;box-shadow:1px 1px 1px 1px #ddd;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style="color:#fff;">
	 <span style="font-size:18px;font-weight:bold;">
	 <span>nellutlalnrao.com</span>
	 </span>
	</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar" style="border:2px solid #fff;">
      <i class="fa fa-bars" style="color:#fff;"></i>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" href="#"><b>Home</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"><b>System Design</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"><b>Blockchain</b></a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<style>
.nav-link, .nav-link:link, .nav-link:visited  { color:#fff !important; }
.navbar-nav .nav-link.active { color:#fff !important;border-bottom:2px solid #fff; }
.nav-link:hover { color:#ccc; }
</style>