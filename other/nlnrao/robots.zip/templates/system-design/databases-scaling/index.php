<div class="container-fluid">
<div class="row">
 <div class="col-xxl-9 col-xl-9 col-sm-9">
  <?php include_once 'templates/breadcrumb.php'; ?>
  <div class="mtop25p"><h3><b>Databases Scaling : Horizontally and Vertically to manage the data from One User to Billion Users</b></h3></div>
 </div>
 <div class="col-xxl-3 col-xl-3 col-sm-3">

 </div>
</div><!--/.row -->
</div><!--/.container-fluid -->